### Statement

​	给一个积性函数：
$$
A:
A(0) = 1,\\
A(p^k) = (p^k+1)
$$
​	求 $A$  的前缀和。

$n\le 10^{13}$

### Solution

$$
=\sum_i i\sum_{i*j\le n} [gcd(i,j)=1]
\\
=\sum_d \mu(d)*d\sum_i i\sum_j[d^2ij\le n]
\\
=\sum_d \mu(d)\sum_i d*i\lfloor \frac {n}{d^2i}\rfloor
$$

可以 $n^{2/3}$

实际上暴力就是根号 log（我们考虑枚举次数是 $\sum \sqrt{\frac{n}{i^2}}$）

瓶颈在 $\text{I}*\text{Id}$ 的前缀和。	
