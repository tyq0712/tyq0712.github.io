http://codeforces.com/problemset/problem/755/G

原题是这个。

### ？pts

倍增FFT。

如果你常数足够牛逼可以卡过 70 pts。

### 70pts

~~随机一个代码粘上来~~

首先你们会发现一个 $F_i = (1+x)F_{i-1} + (1+x)F_{i-2}$

这样实际上是可以解出来通项公式的，复杂度一个log。

如果你常数足够牛逼（也许）可以卡过100pts。

### 100pts

枚举有多少组是两个的：
$$
ans_i = \sum_j \binom{i}{j}\binom{n-j}{i}\\
\binom{n-j}{i}=\sum_k\binom{j}{k}\binom{n-k}{i-k}(-1)^k
$$
拆组合意义，相当于 $n$ 个箱子，在前 $i$ 个中选任意个，然后在前 $n$ 个中选 $i$ 个，要求不重复。

容斥有多少个重复了：
$$
ans_i=\sum_j (-1)^j\binom{i}{j}\binom{n-j}{i-j}2^{i-j}
$$
一次卷积即可计算。

复杂度 $n\log n$。